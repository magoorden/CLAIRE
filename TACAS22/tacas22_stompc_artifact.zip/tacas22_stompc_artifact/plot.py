#!/bin/python3

import sys
import csv
import matplotlib.pyplot as plt
import dateutil

if len(sys.argv) < 2:
    print("Missing path")
    exit()


fields = sys.argv[2:]
legend = []
data = {}
with open(sys.argv[1]) as raw:
    csv_raw = csv.reader(raw)
    
    is_legend = True
    for line in csv_raw:
        if is_legend:
            legend = line
            is_legend = False
        else:
            for i in range(0, len(legend)):
                field = legend[i]
                if field not in data:
                    data[field] = []
                if '-' in line[i] and ':' in line[i]: # we guess that it is a date
                    data[field].append(dateutil.parser.parse(line[i]))
                else:
                    data[field].append(float(line[i])) # just treat it as a float


if len(fields) == 0:
    fields = legend

fig, ax = plt.subplots()
for l in fields[1:]:
    ax.plot(data[fields[0]], data[l], label=l)

ax.set_xlabel(fields[0])
ax.set_title(sys.argv[1])
ax.legend()
plt.show()
