#!/bin/bash

PATH=$(pwd)/../bin/uppaal-4.1.20-stratego-8-beta13-linux64/bin/:$PATH python3 scripts/swmm_stratego_control.py "$@"
