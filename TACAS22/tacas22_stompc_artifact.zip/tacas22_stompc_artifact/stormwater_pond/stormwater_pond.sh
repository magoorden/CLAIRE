#!/bin/bash

PATH=$PATH:$(pwd)/../bin/ python3 scripts/swmm_stratego_control.py "$@"
