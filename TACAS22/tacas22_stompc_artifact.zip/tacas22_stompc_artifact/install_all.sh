#!/bin/bash

pip install strategoutil
pip install pyswmm

# The module below is only needed for plotting the results.
pip install matplotlib

./install_cases.sh

