#!/bin/bash

pip install strategoutil
pip install pyswmm

./install_stratego.sh
./install_cases.sh
