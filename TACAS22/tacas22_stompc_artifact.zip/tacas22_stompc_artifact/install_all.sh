#!/bin/bash

pip install strategoutil
pip install pyswmm

bash install_stratego.sh
bash install_cases.sh
