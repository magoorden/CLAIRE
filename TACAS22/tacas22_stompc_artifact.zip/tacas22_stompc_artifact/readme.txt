# Artifact Evaluation Instruction: TACAS 2022 Submission

Here we explain how to reproduce the results of the TACAS 2022 submission **STOMPC: Stochastic Model-Predictive Control with Uppaal Stratego**.
More concretely, we show how to
1. Prepare your machine in order to run STOMPC.
2. Reproduce the results using pre-written scripts.
3. Use the tool in general (robustness testing).


## Paper abstract
We present the new tool STOMPC for stochastic model-predictivecontrol (MPC) with Uppaal Stratego. The tool allows usersto easily set up MPC designs, a widely accepted method for designingsoftware controllers in industry, with Uppaal Stratego as the controllersynthesis engine, which provides a powerful tool to synthesize safe andoptimal strategies for hybrid stochastic systems. STOMPC provides theuser freedom to connect it to external simulators, making the tool applicableacross multiple domains.


## Statement on archival
The artifact, on passing the artifact evaluation review, would be archived on [Zenodo](https://zenodo.org/), except the contents of Uppaal Stratego. Outside this artifact evaluation, Uppaal Stratego needs to be downloaded from the tools [website](https://people.cs.aau.dk/~marius/stratego/). 
Furthermore, the source code of STOMPC can be access on [GitHub](https://github.com/mihsamusev/strategoutil). [Online documentation](https://strategoutil.readthedocs.io/en/latest/index.html) of STOMPC is available.


## Preparation
This section describes the preparation before the tool can be used.


### Contents of this artifact
This artifact contains the following files and folders:
- `installation` containing the installation files for offline installation.
- `room_heating` containing the files for the floor heating case.
- `stormwater_pond` containing the files for the stormwater pond case.
- `install_*.sh` are installation scripts.
- `license.txt` containing the license text.
- `readme.txt` is this file.
- `TACAS_22_first_submission.pdf` is the manuscript submitted for review.
- `uppaal64-4.1.20-stratego-7.zip` is Uppaal Stratego 7 download (not included in the archived artifact)
- `verifyta` contains a fix related to Uppaal Stratego 7.


### Technical setup

We assume that you start on a clean version of the [TACAS 2022 VM](https://doi.org/10.5281/zenodo.5562597) and use it only for this evaluation. Hence, we do not bother with virtual environments.

Note that we always assume you are inside our unzipped artifact folder (`tacas2-stompc-artifact`) and give paths relative to that. 
E.g. just executing `ls` should result in seeing the folders `installation` and `stormwater_pond` as well as 6 files (including this one).

The easiest way to install STOMPC (and the intended way) is to install it using an active internet connection. This will install the latest version of our tool.
It might be that you do not have one for this artifact evaluation, so we also provide instructions on how to install the tool without one. This will install v0.0.6 of STOMPC.

Beside following the instructions in this readme file, one can also follow the instructions from the [online documentation](https://strategoutil.readthedocs.io/en/latest/installation.html#) of our tool.
In this artifact, we have scripted these steps specifically for the TACAS 2022 VM.

We have tested this artifact submission running the TACAS 2022 VM on a MacBook Pro running macOS 11.6 and Oracle VM VirtualBox.

### Installing everything automatically
In case you have an active internet connection, you can execute the following script to install everything in one go.

	$ bash install_all.sh

After running this script, you need to restart the VM. You can skip the rest of this installation section.
Otherwise, you can follow the steps of the next sections for manual installation.


### Installing STOMPC using an internet connection
We can simply download and install STOMPC using `pip3`:

	$ pip install strategoutil

For one of the case studies, we will need pySWMM, which can also be installed using `pip3`:

	$ pip install pySWMM


### Installing STOMPC without internet connection
For an installation without an active internet connection, go to the folder `installation` and execute

	$ cd installation
	$ pip install *


### Installing Uppaal Stratego
While Uppaal Stratego can also be downloaded directly from the internet, downloading it requires the reviewer to identifies himself or herself while agreeing with the license. 
Therefore, we have included the downloaded zip-file with the artifact. 
Nonetheless, the reviewer can still download the latest version of [Uppaal Stratego](https://people.cs.aau.dk/~marius/stratego/), place the zip-file in the artifact folder, and continue with the same instructions below.

Install Uppaal Stratego with the supplied bash-file:

	$ bash install_stratego.sh


### Preparing the case studies
We need to do some final preparation for the case studies, for example adapting some hard-coded paths in Uppaal models with the correct ones.
To do this preparation, run the following bash-file:

	$ bash install_cases.sh

	
### Restart the virtual machine
This step is only needed for the TACAS 2022 VM, as it is a fresh one. 
For STOMPC to work, it need to have `~/.local/bin` in the path, which is not the case when the TACAS 2022 VM is started for the first time.
Restarting the virtual machine adds `~/.local/bin` to the path.
After restarting, you can check this with

	$ echo $PATH

It should contain `/home/tacas22/.local/bin` now.

Note for advanced users: it is insufficient for STOMPC to have `~/.local/bin` added to the path in the `.bashrc` file, as you might normally do for adding folders to the path variable. 
STOMPC runs processes without having the `.bashrc` profile loaded.


## Scripted case studies
For each case study below, we assume that the reviewer is in the top level of the artifact.


### Floor heating
First, navigate to the folder for the floor heating case study with

	$ cd room_heating

Now, you can run the experiment with

	$ python3 room_heating_online_control.py

Progress will be printed to the terminal. Running the experiment will take less than a minute.
The results are written to the file `results.txt` in the same folder.


### Stormwater pond
First, navigate to the folder for the stormwater pond case study with

	$ cd stormwater_pond/scripts
	
Now, you can run the experiment with

	$ python3 swmm_stratego_control.py
	
Progress will be printed to the terminal. Running the experiment will take several minutes.
The results are written to

	$ cd ../swmm_models

in the file `swmm_results.txt`.


## Robustness testing
There are several ways to perform robustness testing with the tool. 
The easiest way is to adjust the scripts of the included cases, which is explained in the sections below. 
Another way is to use the tool for another case. As inspiration for that option, Appendix A from the paper explains the setup of the script for the stormwater pond in more detail and the reasoning behind them. We do not discuss this second option further in this readme file. 

The full reference documentation of the tool can be found in the [online documentation](https://strategoutil.readthedocs.io/en/latest/api.html).


### Floor heating
In this case study, Uppaal Stratego is used for both the strategy synthesis engine as well as simulation engine. That makes the setup very straightforward. 

The first change one could make is using different values for the MPC scheme in the script `room_heating_online_control.py`. Both `horizon` and `duration` can be changed. 
Unfortunately, `period` has been hard-coded into the Uppaal Stratego model.
Yet, the model could be changed such that the actual value is supplied by STOMPC. This is left as an exercise for the reader (as lecture notes would say).

Second, one could change the optimization criteria in `room_heating_online_control.py`. In the original model, the distance between the room temperature and target temperature is minimized.
One could for example change this into maximizing the difference:

	line 1 = "strategy opt = maxE (D) [<={}*{}]: <> (t=={})\n"

Finally, one could change the values in the two configuration files `model_config.yaml` and `verifyta_config.yaml`.

The results are written to the file `results.txt` in the same folder.


### Stormwater pond
This case study shows how an external simulator can be utilized by STOMPC. Changes can be made at the places described below.

The first change one could make is using different values for the MPC scheme. 
In the script `scripts/swmm_stratego_control.py`, `horizon` can be changed. 
Unfortunately, `period` has been hard-coded into the Uppaal Stratego model.
Yet, the model could be changed such that the actual value is supplied by STOMPC. This is left as an exercise for the reader (as lecture notes would say).
The duration of the experiment needs to be adjusted in the SWMM model `swmm_models/swmm_model.inp`. At the beginning of this file, you can find and change `START_DATE`, `START_TIME`, `END_DATE`, and `END_TIME`. Just make sure for simplicity that `REPORT_START_DATE` is the same as `START_DATE` and `REPORT_START_TIME` as `START_TIME`.

Changing the initial values of model variables is more difficult for this case compared to the floor heating case, as they have to be changed in both `uppaal/pond_experiment_conf.yaml` for the Uppaal Stratego model as well as in `swmm_models/swmm_model.inp`, such that the two models describe the same system.
Therefore, it is not recommended that the review tries to change them.

On the other hand, the review is free to change the learning settings used by Uppaal Stratego.
These settings are located in `uppaal/verifyta_config.yaml`. The meaning of these settings can be obtained through the help of Uppaal Stratego with the following command

	$ verifyta-stratego-7 -h
