#!/bin/bash

artifact_folder=$(pwd)

mkdir -p bin
unzip -o -q uppaal64-4.1.20-stratego-7.zip -d bin
cd bin
ln -s uppaal64-4.1.20-stratego-7/bin-Linux/verifyta verifyta-stratego-7

new_verifyta_file="$artifact_folder/verifyta"
cp -f $new_verifyta_file "$artifact_folder/bin/uppaal64-4.1.20-stratego-7/bin-Linux/verifyta"

