#!/bin/bash

artifact_folder=$(pwd)

mkdir -p ~/.local/bin
unzip -o -q uppaal64-4.1.20-stratego-7.zip -d $HOME/.local/bin
cd ~/.local/bin
ln -s uppaal64-4.1.20-stratego-7/bin-Linux/verifyta verifyta-stratego-7

new_verifyta_file="$artifact_folder/verifyta"
cp -f $new_verifyta_file "~/.local/bin/uppaal64-4.1.20-stratego-7/bin-Linux/verifyta"

