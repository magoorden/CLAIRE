#!/bin/bash

PATH=$PATH:$(pwd)/../bin/ python3 room_heating_online_control.py "$@"
