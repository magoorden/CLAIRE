#!/bin/bash

artifact_folder=$(pwd)

# Build the c-library to read external data into Uppaal models.
cd stormwater_pond/uppaal-libs-main
bash cmake-linux64.sh
pond_folder="$artifact_folder/stormwater_pond/uppaal"
cp -f cmake-linux64-release/libtable.so $pond_folder

cd $pond_folder

# Replace path to libtable.so in Upaal model.
search="import \"\(.*\)/libtable.so"
sed -i "s@$search@import \"$pond_folder\/libtable.so@" $pond_folder/pond_experiment.xml

# Replace path to weather_forecast.csv in Uppaal model.
search="table_read_csv(\(.*\)/weather_forecast.csv"
sed -i "s@$search@table_read_csv(\"$pond_folder\/weather_forecast.csv@" $pond_folder/pond_experiment.xml
